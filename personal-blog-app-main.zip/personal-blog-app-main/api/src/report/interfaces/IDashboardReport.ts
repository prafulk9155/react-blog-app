export interface IDashboardReport {
  articleCount: number
  pageCount: number
  fileCount: number
}
