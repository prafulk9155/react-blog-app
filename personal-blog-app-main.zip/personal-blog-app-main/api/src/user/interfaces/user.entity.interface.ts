export interface IUserEntity {
  readonly userId: string
  readonly userName: string
}
