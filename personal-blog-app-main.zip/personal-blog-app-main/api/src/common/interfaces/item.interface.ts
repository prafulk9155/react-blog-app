export interface IItem {
  readonly title: string
}
