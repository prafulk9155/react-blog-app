export class UserMessage {
  EXISTING_USER = 'Bu email veya kullanıcı adı zaten kullanılıyor.'
  WRONG_USERNAME_PASSWORD = 'Kullanıcı adı veya parolanız yanlış.'
}
