export class TagMessage {
  EXISTING_GUID =
    'Aynı kısa isimli başka bir etiket var. Lütfen tekrar deneyiniz.'
}
