export class PageMessage {
  EXISTING_GUID =
    'Aynı kısa isimli başka bir makale veya sayfa var. Lütfen tekrar deneyiniz.'
}
