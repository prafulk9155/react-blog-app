export class CategoryMessage {
  EXISTING_GUID =
    'Aynı kısa isimli başka bir kategori var. Lütfen tekrar deneyiniz.'
  USE = 'Bu kategorinin alt kategorisi olduğu için silemezsiniz.'
}
