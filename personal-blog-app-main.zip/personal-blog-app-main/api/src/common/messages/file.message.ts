export class FileMessage {
  UPLOAD_ERROR =
    'Dosya yüklenirken bir sorun oluştu. Dosyayı doğru şekilde yüklemeye çalıştığınızdan emin olunuz.'
  EXISTING_FOLDER =
    'Silmeye çalıştığınız klasör içinde klasör veya dosyalar bulunmaktadır. İçerisindekileri sildikten sonra deneyiniz.'
  EXISTING_FILE =
    'Silmeye çalıştığınız dosya makale veya sayfalarda kullanılmaktadır.'
}
