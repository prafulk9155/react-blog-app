"use client";

// ** components
import NewEditArticle from "@/components/admin/articles/NewEditArticle";

export default function AdminArticleNew() {
  return <NewEditArticle />;
}
