"use client";

// ** components
import NewEditPage from "@/components/admin/pages/NewEditPage";

export default function AdminPageNew() {
  return <NewEditPage />;
}
