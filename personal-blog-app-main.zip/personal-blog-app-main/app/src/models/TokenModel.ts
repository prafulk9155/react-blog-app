export default interface TokenModel {
  readonly accessToken: string
  readonly userId: string
}
