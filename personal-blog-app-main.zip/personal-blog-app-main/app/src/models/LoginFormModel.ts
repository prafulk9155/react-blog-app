type LoginFormModel = {
  readonly username: string
  readonly password: string
}

export default LoginFormModel
