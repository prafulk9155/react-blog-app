export default interface AdminDashboardModel {
  readonly articleCount: number
  readonly pageCount: number
  readonly fileCount: number
}
