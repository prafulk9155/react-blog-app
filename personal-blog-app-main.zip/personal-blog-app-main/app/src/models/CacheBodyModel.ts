type CacheBodyModel = {
  readonly path: string;
  readonly type?: "page" | "layout";
};

export default CacheBodyModel;
